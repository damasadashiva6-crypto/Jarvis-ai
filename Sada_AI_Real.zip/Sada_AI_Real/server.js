const express = require("express");
const OpenAI = require("openai");
const path = require("path");

const app = express();
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({error:"Message is empty."});

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions: "You are Sada AI, a friendly personal assistant. Reply naturally and helpfully. The user may use Hindi, Hinglish, Kannada, or English; match their language.",
      input: message
    });

    res.json({reply: response.output_text});
  } catch (e) {
    console.error(e);
    res.status(500).json({error:"AI request failed. Check the server API key and billing/access."});
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`SADA AI running on http://localhost:${port}`));
