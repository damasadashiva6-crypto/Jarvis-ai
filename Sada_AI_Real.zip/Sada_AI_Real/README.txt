SADA AI — REAL AI VERSION

This project keeps the neon-green hacker UI and sends messages through a server to the OpenAI Responses API.

IMPORTANT:
- Never put your API key in public/index.html or a mobile/browser app.
- Keep OPENAI_API_KEY in the server environment.
- API usage can cost money depending on your account/model usage.

FILES:
- public/index.html  = green SADA AI interface
- server.js          = secure backend endpoint
- package.json       = dependencies
- .env.example       = environment variable template

RUN ON A SERVER:
1. Install Node.js.
2. Run: npm install
3. Set OPENAI_API_KEY in the server environment.
4. Run: npm start
5. Open the server URL.

For Android-only use, you still need a server/hosting service for the backend. The browser UI alone cannot safely contain the secret API key.
