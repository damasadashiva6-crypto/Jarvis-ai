SADA AI — Hacker-style Android UI
Open index.html in a browser or HTML editor.
The green terminal-style interface is ready.
For real AI replies, connect a secure backend; never expose your API key in this HTML file.
